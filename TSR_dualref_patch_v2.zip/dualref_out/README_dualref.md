# TSR Dual-Reference Patch

This patch keeps the original official TSR baseline untouched and adds a **dual-reference training path**:

- **global reference**: the first frame in the same sequence
- **local reference**: the previous frame in the same sequence
- **reference encoding**: shared encoder + reference type embeddings
- **fusion**: axial self-attention on the current frame, then global cross-attention over concatenated reference tokens

## Added files

- `TSR_train_dualref.py`
- `datasets/dataset_TSR_dualref.py`
- `src/TSR_trainer_dualref.py`
- `src/models/transformer_dualref.py`
- `src/models/TSR_model_dualref.py`

## Dataset assumption

The image list in `--data_path` / `--validation_path` should contain frame paths whose **parent directory identifies the sequence**.
Frames are sorted lexicographically inside each sequence.

## Reference streams

- Global reference: first frame of each sequence
- Local reference: previous frame of each sequence
- For the first frame, the local reference is zero-padded and masked out

## Training entry

Run the new entry instead of the original one:

```bash
python TSR_train_dualref.py \
  --GPU_ids 0 \
  --data_path train_imgs.txt \
  --validation_path val_imgs.txt \
  --train_line_path /path/to/train_pkls \
  --val_line_path /path/to/val_pkls \
  --mask_path "['irregular_mask_list.txt','coco_mask_list.txt']" \
  --valid_mask_path /path/to/val_masks \
  --batch_size 8 --train_epoch 12 --AMP
```

## Optional ablations

- `--no_global_ref`: disable the first-frame reference stream
- `--no_local_ref`: disable the previous-frame reference stream



## Updated data-list convention
- `data_path`: txt listing training image paths
- `train_line_path`: txt listing training pkl paths, one-to-one aligned with `data_path`
- `validation_path`: txt listing validation image paths
- `val_line_path`: txt listing validation pkl paths, one-to-one aligned with `validation_path`
- `mask_path`: a single txt listing all training masks; do not wrap it in `[]`
- `valid_mask_path`: can be either a txt listing validation masks or a directory of masks
